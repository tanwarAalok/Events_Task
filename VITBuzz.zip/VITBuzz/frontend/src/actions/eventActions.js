import axios from "axios";
import { ALL_EVENT_FAIL, ALL_EVENT_REQUEST, ALL_EVENT_SUCCESS, NEW_EVENT_FAIL, NEW_EVENT_REQUEST, NEW_EVENT_SUCCESS } from "../constants/eventConstants";


export const getEvents = (keyword = "") => async (dispatch) => {
    try {
        dispatch({ type: ALL_EVENT_REQUEST });
        let link = "/events";
        if (keyword) {
            link = `/events?event_name=${keyword}`;
        }
        const { data } = await axios.get(link);

        dispatch({
            type: ALL_EVENT_SUCCESS,
            payload: data,
        });
    } catch (err) {
        dispatch({
            type: ALL_EVENT_FAIL,
            payload: err.response.data.message,
        })
    }
}

export const createNewEvent = (eventData) => async (dispatch) => {
    try {
        dispatch({ type: NEW_EVENT_REQUEST });
        const config = {
            headers: { "Content-Type": "application/json" },
        };

        const { data } = await axios.post(
            `/newEvent`,
            eventData,
            config
        );

        dispatch({
            type: NEW_EVENT_SUCCESS,
            payload: data
        });

    } catch (error) {
        dispatch({
            type: NEW_EVENT_FAIL,
            payload: error.response.data.message
        });
    }
};