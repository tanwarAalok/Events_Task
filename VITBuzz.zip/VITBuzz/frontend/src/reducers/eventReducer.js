import { ALL_EVENT_FAIL, ALL_EVENT_REQUEST, ALL_EVENT_SUCCESS, CLEAR_ERRORS, NEW_EVENT_FAIL, NEW_EVENT_REQUEST, NEW_EVENT_RESET, NEW_EVENT_SUCCESS } from "../constants/eventConstants";


export const eventReducer = (state = { events: [] }, action) => {
    switch (action.type) {
        case ALL_EVENT_REQUEST:
            return {
                loading: true,
                events: [],
            };
        case ALL_EVENT_SUCCESS:
            return {
                loading: false,
                events: action.payload.events
            };
        case ALL_EVENT_FAIL:
            return {
                loading: false,
                error: action.payload
            };
        case CLEAR_ERRORS:
            return {
                ...state,
                error: null
            };
        default:
            return state;

    }
};

export const newEventReducer = (state = { event: {} }, action) => {
          switch (action.type) {
            case NEW_EVENT_REQUEST:
              return {
                ...state,
                loading: true,
              };
            case NEW_EVENT_SUCCESS:
              return {
                loading: false,
                success: action.payload.success,
                event: action.payload.event,
              };
            case NEW_EVENT_FAIL:
              return {
                ...state,
                loading: false,
                error: action.payload,
              };
            case NEW_EVENT_RESET:
              return {
                ...state,
                success: false,
              };
            case CLEAR_ERRORS:
              return {
                ...state,
                error: null,
              };
            default:
              return state;
          }
}