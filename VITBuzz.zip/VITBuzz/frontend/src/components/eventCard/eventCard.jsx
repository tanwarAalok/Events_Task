import React, { useEffect, useState } from 'react';
import './eventCard.css';
import { registerEvent } from '../../actions/userActions';
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from 'react-router-dom';
import { clearErrors } from '../../actions/userActions';

const EventCard = ({ event }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useSelector((state) => state.user);
  const { registered, error } = useSelector((state) => state.eventRegistered);
  const [alreadyRegistered, setalreadyRegistered] = useState(false);
  

  

  useEffect(() => {
    if (error) {
      // alert(error);
      dispatch(clearErrors);
    }

    if (!isAuthenticated) return;

    const checkRegistered = () => {
      if (isAuthenticated && user.eventsRegistered.length > 0) {
        user.eventsRegistered.map((id) =>
          id.toString() === event._id.toString()
            ? setalreadyRegistered(true)
            : ""
        );
      }
    };
    checkRegistered();
  }, [dispatch, error, event, isAuthenticated, alreadyRegistered]);

  const registerForEvent = () => {
    if (!isAuthenticated) {
      alert("You must login to register");
      return navigate("/login");
    }

    dispatch(registerEvent(event._id, user._id));
    setalreadyRegistered(true);
  }

  return (
    <div className="eventCard_container">
      <div>
        <h2>{event.event_name}</h2>
        <p>Start: {event.event_start_timestamp}</p>
        <p>End: {event.event_end_timestamp}</p>
      </div>
      <div>
        <p>Slots Left: {event.event_capacity}</p>
        <button onClick={registerForEvent}>
          {isAuthenticated &&
           alreadyRegistered ? "Un-register" : "Register"}
        </button>
      </div>
    </div>
  );
}

export default EventCard;