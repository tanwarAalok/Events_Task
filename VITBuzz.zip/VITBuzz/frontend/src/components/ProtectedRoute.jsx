import React from 'react'
import { useSelector } from 'react-redux';
import { Outlet, Navigate} from "react-router-dom";

const ProtectedRoute = () => {
    
    const { isAuthenticated, user } = useSelector((state) => state.user);

    return (
        (isAuthenticated && user.role === "admin") ? <Outlet /> : <Navigate to={"/"}/>
    )
};

export default ProtectedRoute;