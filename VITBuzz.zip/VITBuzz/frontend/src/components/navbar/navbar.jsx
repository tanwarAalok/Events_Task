import React, {useState} from 'react'
import "./navbar.css"
import { Link } from "react-router-dom";
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../../actions/userActions';

const Navbar = () => {
  
  let navigate = useNavigate();
  const [keyword, setKeyword] = useState("");

  const dispatch = useDispatch();

  const searchSubmitHandler = (e) => {
    e.preventDefault();
    if (keyword.trim()) {
      navigate(`/search/${keyword}`, { replace: true });
    } else {
      navigate("/", { replace: true });
    }
  };

  function logoutUser() {
    dispatch(logout());
  }

  const { isAuthenticated , user} = useSelector((state) => state.user);

  return (
    <div className="navbarContainer">
      <Link to={"/"}>VITBuzz</Link>
      <form className="searchBar" onSubmit={searchSubmitHandler}>
        <input
          onChange={(e) => setKeyword(e.target.value)}
          type="text"
          placeholder="Search for Events.."
        />
      </form>
      {isAuthenticated ? (
        <div>
          {user.role === "admin" ? (<Link to={"/newEvent"}>New Event</Link>) : ""}
          <Link onClick={logoutUser} to={"/"}>
            Logout
          </Link>
        </div>
      ) : (
        <Link to={"/login"}>Login</Link>
      )}
    </div>
  );
}

export default Navbar;
