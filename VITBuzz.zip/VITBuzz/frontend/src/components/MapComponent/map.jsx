import React  from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";


const position = [28.55616, 77.100281];

export default function MapComponent({events}) {

  return (
    <>
      <MapContainer center={position} zoom={5} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {events &&
          events.map((e, index) => (
            <Marker
              key={index}
              position={[e.event_location.Lat, e.event_location.Lon]}
            >
              <Popup>{e.event_name}</Popup>
            </Marker>
          ))}
      </MapContainer>
    </>
  );
}

//
