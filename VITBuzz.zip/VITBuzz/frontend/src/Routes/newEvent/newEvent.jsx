import React, {useState} from 'react'
import "./newEvent.css";
import { createNewEvent } from '../../actions/eventActions';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';

const NewEvent = () => {

    const dispatch = useDispatch();
    let navigate = useNavigate();

    const [name, setName] = useState("");
    const [start, setstart] = useState("");
    const [end, setEnd] = useState("");
    const [lat, setLat] = useState(0);
    const [lon, setLon] = useState(0);
    const [capacity, setCapacity] = useState(50);

    const formSubmit = (e) => {
        e.preventDefault();

        const myform = {
          event_name: name,
          event_start_timestamp: start,
          event_end_timestamp: end,
          event_location: {
            Lat: lat,
            Lon: lon,
          },
          event_capacity: 60,
        };

        console.log("myform: ", myform);

        dispatch(createNewEvent(myform));
        alert("Event created succesfully");
        navigate("/");
    }

  return (
    <div className="newEventPage">
      <form
        className="newEventContainer"
        onSubmit={formSubmit}
      >
        <div>
          <h2>Create New Event</h2>
        </div>
        <div>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            type="text"
            placeholder="Event Name"
          />
          <input
            value={start}
            onChange={(e) => setstart(e.target.value)}
            required
            type="datetime-local"
            placeholder="Start Date"
          />
          <input
            value={end}
            onChange={(e) => setEnd(e.target.value)}
            required
            type="datetime-local"
            placeholder="End Date"
          />
          <input
            value={lat}
            onChange={(e) => setLat(e.target.value)}
            required
            type="number"
            placeholder="Location Latitude"
          />
          <input
            value={lon}
            onChange={(e) => setLon(e.target.value)}
            required
            type="number"
            placeholder="Location Longitude"
          />
          <input
            value={capacity}
            onChange={(e) => setCapacity(e.target.value)}
            type="number"
            placeholder="Slots avaiable"
          />
        </div>

        <div>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  );
}

export default NewEvent;