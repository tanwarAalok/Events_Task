import React, {useEffect, useState} from 'react'
import "./Auth.css";
import { Link, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { login, clearErrors } from '../../actions/userActions';

const Login = () => {

  const dispatch = useDispatch();
  let navigate = useNavigate();

  const { error, isAuthenticated } = useSelector((state) => state.user);

  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");

  const loginSubmit = (e) => {
    e.preventDefault();
    dispatch(login(loginEmail, loginPassword));
  }

  useEffect(() => {
    if (error) {
      dispatch(clearErrors());
    }

    if (isAuthenticated) {
      alert("User login successfull")
      navigate('/');
    }
  }, [dispatch, isAuthenticated, error, navigate]);

  return (
    <div className="authPage">
      <form className="auth_container" onSubmit={loginSubmit}>
        <div>
          <h2>Login</h2>
        </div>
        <div>
          <input value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} type="email" placeholder="Email" required/>
          <input value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} type="password" placeholder="Password" required/>
        </div>

        <div>
          <Link to={"/register"}>Register</Link>
          <button type='submit'>Login</button>
        </div>
      </form>
    </div>
  );
}

export default Login