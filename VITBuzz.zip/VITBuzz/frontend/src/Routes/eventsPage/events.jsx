import React, { useEffect } from 'react';
import "./events.css";
import MapComponent from "../../components/MapComponent/map";
import EventCard from "../../components/eventCard/eventCard";
import { getEvents } from '../../actions/eventActions';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';

const Events = () => {

  const { keyword } = useParams();

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getEvents(keyword));
  }, [dispatch, keyword]);

  const events = useSelector((state) => state.events.events);

  return (
    <div className="eventsPage">
      <div>
        {events &&
          events.map((event, index) => <EventCard key={index} event={event} />)}
      </div>
      <div>
        <MapComponent events={events} />
      </div>
    </div>
  );
}

export default Events