import { createStore, combineReducers, applyMiddleware } from "redux";
import thunk from "redux-thunk";
import { composeWithDevTools } from "redux-devtools-extension";
import { eventReducer, newEventReducer } from "./reducers/eventReducer";
import { userReducer, eventregisterReducer } from "./reducers/userReducer";

const reducer = combineReducers({
  events: eventReducer,
  newEvent: newEventReducer,
  user: userReducer,
  eventRegistered: eventregisterReducer
});

let initialState = {};

const middleware = [thunk];

const store = createStore(
  reducer,
  initialState,
  composeWithDevTools(applyMiddleware(...middleware))
);

export default store;
