import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Events from "./Routes/eventsPage/events";
import Navbar from "./components/navbar/navbar";
import Login from './Routes/AuthPage/Login';
import Register from './Routes/AuthPage/Register';
import NewEvent from "./Routes/newEvent/newEvent";
import { useSelector } from "react-redux";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Events />} />
        <Route path="/search/:keyword" element={<Events />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/newEvent" element={<NewEvent />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
